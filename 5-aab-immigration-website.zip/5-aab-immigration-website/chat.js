
(function(){
 const box=document.getElementById('chatBox'), launch=document.getElementById('chatLaunch'), close=document.getElementById('chatClose');
 if(!box||!launch) return;
 launch.addEventListener('click',()=>{box.classList.toggle('open'); if(box.classList.contains('open')) document.getElementById('chatInput')?.focus();});
 close?.addEventListener('click',()=>box.classList.remove('open'));
 const messages=document.getElementById('chatMessages'), form=document.getElementById('chatForm'), input=document.getElementById('chatInput');
 function bubble(text,who){const el=document.createElement('div');el.className='bubble '+who;el.textContent=text;messages.appendChild(el);messages.scrollTop=messages.scrollHeight;}
 function answer(q){
  const s=q.toLowerCase();
  if(s.includes('contact')||s.includes('phone')||s.includes('number')||s.includes('call')) return 'You can call 9056274492 or email PANJAABIMMI@GMAIL.COM. Our owner is Ajaydeep Singh.';
  if(s.includes('address')||s.includes('location')||s.includes('office')||s.includes('map')) return 'Head office: 1410, Sunny Enclave, Sunny Club Road, Sector 125, Kharar, SAS Nagar, Mohali, Punjab 140301. Use the Google Maps link on this website for directions.';
  if(s.includes('gallery')||s.includes('client')||s.includes('photo')||s.includes('approval')) return 'Open the Client Gallery page to view the 35 photos supplied for this website.';
  if(s.includes('instagram')||s.includes('social')) return 'Instagram: @5_aab_immi. The social links are available in the website footer.';
  if(s.includes('visa')||s.includes('immigration')||s.includes('country')||s.includes('work')||s.includes('study')) return 'Visa requirements depend on your destination and personal situation. Contact our team at 9056274492 or PANJAABIMMI@GMAIL.COM for case-specific information. Visa approval is never guaranteed.';
  return 'I can help with contact details, office location, the client gallery, and general enquiry routing. For advice about a specific visa case, please contact 9056274492 or PANJAABIMMI@GMAIL.COM.';
 }
 function send(q){q=(q||'').trim();if(!q)return;bubble(q,'user');bubble(answer(q),'bot');}
 form?.addEventListener('submit',e=>{e.preventDefault();send(input.value);input.value='';});
 document.querySelectorAll('[data-chat-question]').forEach(b=>b.addEventListener('click',()=>send(b.textContent)));
 bubble('Hello! I’m the 5 AAB website support assistant. What would you like help with?','bot');
})();
