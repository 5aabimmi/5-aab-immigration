5 AAB IMMIGRATION WEBSITE
========================

Files:
- index.html       Home page
- gallery.html     Client Gallery page with all 35 supplied photos
- styles.css       Responsive site styling
- chat.js          Floating website support helper
- assets/logo.jpeg Immigration logo
- assets/clients/  35 client photos extracted from the supplied ZIP

HOW TO PUBLISH ON GITHUB PAGES
1. Extract this ZIP on your computer.
2. Open your GitHub repository for the website.
3. Upload the CONTENTS of this folder (not the outer folder) into the repository root.
4. Commit the changes.
5. In repository Settings > Pages, choose the correct branch and / (root), then save.
6. Open the published website. The Client Gallery link in the navigation opens gallery.html.

CHAT NOTE
The floating "AI Support" button is a front-end FAQ helper with preset responses. It is not connected to a live AI model or a human agent. A real AI chat requires a secure server/API integration; do not put secret API keys in public HTML/JavaScript.

IMPORTANT
Please ensure you have consent to publish clients' photos. The website does not guarantee visa approval.
